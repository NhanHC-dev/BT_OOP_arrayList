package utils.exception;

public class ProducerFullException extends Exception {
    public ProducerFullException(String message){
        super(message);
    }
}
